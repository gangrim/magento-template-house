<?php 


class Thirty4_CatalogSale_Block_Carousel
  extends Thirty4_CatalogSale_Block_List
{
}
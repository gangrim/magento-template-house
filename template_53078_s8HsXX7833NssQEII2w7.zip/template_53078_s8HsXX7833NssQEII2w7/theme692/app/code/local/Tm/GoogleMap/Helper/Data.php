<?php 

class Tm_GoogleMap_Helper_Data extends Mage_Core_Helper_Data
{
	
}